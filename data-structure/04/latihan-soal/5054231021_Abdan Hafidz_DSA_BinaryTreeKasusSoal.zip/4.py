import math
val = list(map(int, input().split()))
x = len(val)
print(math.floor(math.log(16,2)) + 1)
