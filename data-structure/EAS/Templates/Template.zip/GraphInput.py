N,M= map(int,input().split())
visited = [0]*N
adj = [set() for _ in range(N+1)]
for _ in range(M):
    U,V = map(int, input().split())
    adj[U].add(V)
    adj[V].add(U)

print(adj[1])
